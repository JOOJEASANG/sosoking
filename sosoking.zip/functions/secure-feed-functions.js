'use strict';

const { onCall, onRequest, HttpsError } = require('firebase-functions/v2/https');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');

const db = getFirestore();
const REGION = 'asia-northeast3';
const ALLOWED_REACTIONS = ['like', 'funny', 'fire', 'skull'];

function cleanId(value, max = 160) {
  return String(value || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, max);
}

function requireUser(request) {
  const uid = request.auth && request.auth.uid;
  if (!uid) throw new HttpsError('unauthenticated', '로그인이 필요합니다.');
  return uid;
}

function clampCount(value) {
  return Math.max(0, Number(value || 0));
}

const castFeedVote = onCall({ region: REGION, timeoutSeconds: 20 }, async (request) => {
  const userId = requireUser(request);
  const safePostId = cleanId(request.data && request.data.postId);
  const optionIdx = Number(request.data && request.data.optionIdx);
  if (!safePostId || !Number.isInteger(optionIdx) || optionIdx < 0) {
    throw new HttpsError('invalid-argument', '투표 정보가 올바르지 않습니다.');
  }

  const postRef = db.doc(`feeds/${safePostId}`);
  const nextOptions = await db.runTransaction(async (tx) => {
    const snap = await tx.get(postRef);
    if (!snap.exists) throw new HttpsError('not-found', '게시글을 찾을 수 없습니다.');
    const post = snap.data() || {};
    if (post.hidden === true) throw new HttpsError('failed-precondition', '공개되지 않은 게시글입니다.');
    if (!['balance', 'vote', 'battle', 'concern'].includes(post.type)) {
      throw new HttpsError('failed-precondition', '투표할 수 없는 게시글입니다.');
    }
    const options = Array.isArray(post.options) ? post.options : [];
    if (!options[optionIdx]) throw new HttpsError('invalid-argument', '존재하지 않는 선택지입니다.');
    if ((post.votedBy || []).includes(userId)) throw new HttpsError('already-exists', '이미 투표했습니다.');

    const updated = options.map((option, index) => {
      const base = typeof option === 'object' && option !== null ? { ...option } : { text: String(option || '') };
      base.votes = Number(base.votes || 0) + (index === optionIdx ? 1 : 0);
      return base;
    });

    tx.update(postRef, {
      options: updated,
      votedBy: FieldValue.arrayUnion(userId),
      updatedAt: FieldValue.serverTimestamp(),
    });
    return updated;
  });

  return { ok: true, options: nextOptions };
});

const toggleFeedReaction = onCall({ region: REGION, timeoutSeconds: 20 }, async (request) => {
  const userId = requireUser(request);
  const safePostId = cleanId(request.data && request.data.postId);
  const key = String(request.data && request.data.reaction || '').trim();
  if (!safePostId || !ALLOWED_REACTIONS.includes(key)) {
    throw new HttpsError('invalid-argument', '반응 정보가 올바르지 않습니다.');
  }

  const postRef = db.doc(`feeds/${safePostId}`);
  const result = await db.runTransaction(async (tx) => {
    const snap = await tx.get(postRef);
    if (!snap.exists) throw new HttpsError('not-found', '게시글을 찾을 수 없습니다.');
    const post = snap.data() || {};
    if (post.hidden === true) throw new HttpsError('failed-precondition', '공개되지 않은 게시글입니다.');

    const current = post.reactedWith && post.reactedWith[userId] ? post.reactedWith[userId] : null;
    const reactions = { ...(post.reactions || {}) };
    reactions.total = clampCount(reactions.total);
    ALLOWED_REACTIONS.forEach(k => { reactions[k] = clampCount(reactions[k]); });

    const patch = { updatedAt: FieldValue.serverTimestamp() };
    let myReaction = key;

    if (current === key) {
      patch[`reactions.${key}`] = FieldValue.increment(-1);
      patch['reactions.total'] = FieldValue.increment(-1);
      patch[`reactedWith.${userId}`] = FieldValue.delete();
      reactions[key] = Math.max(0, reactions[key] - 1);
      reactions.total = Math.max(0, reactions.total - 1);
      myReaction = null;
    } else if (current && ALLOWED_REACTIONS.includes(current)) {
      patch[`reactions.${current}`] = FieldValue.increment(-1);
      patch[`reactions.${key}`] = FieldValue.increment(1);
      patch[`reactedWith.${userId}`] = key;
      reactions[current] = Math.max(0, reactions[current] - 1);
      reactions[key] += 1;
    } else {
      patch[`reactions.${key}`] = FieldValue.increment(1);
      patch['reactions.total'] = FieldValue.increment(1);
      patch[`reactedWith.${userId}`] = key;
      reactions[key] += 1;
      reactions.total += 1;
    }

    tx.update(postRef, patch);
    return { reactions, myReaction };
  });

  return { ok: true, ...result };
});

const registerPostView = onCall({ region: REGION, timeoutSeconds: 15 }, async (request) => {
  const userId = requireUser(request);
  const safePostId = cleanId(request.data && request.data.postId);
  if (!safePostId) throw new HttpsError('invalid-argument', '게시글 정보가 없습니다.');

  const postRef = db.doc(`feeds/${safePostId}`);
  const viewRef = postRef.collection('viewers').doc(userId);
  const now = Date.now();
  const intervalMs = 6 * 60 * 60 * 1000;
  let counted = false;

  await db.runTransaction(async (tx) => {
    const postSnap = await tx.get(postRef);
    if (!postSnap.exists || (postSnap.data() || {}).hidden === true) throw new HttpsError('not-found', '게시글을 찾을 수 없습니다.');
    const viewSnap = await tx.get(viewRef);
    const lastViewedAtMs = Number(viewSnap.exists ? viewSnap.data().lastViewedAtMs || 0 : 0);
    if (lastViewedAtMs > now - intervalMs) {
      tx.set(viewRef, { lastSeenAt: FieldValue.serverTimestamp(), lastSeenAtMs: now }, { merge: true });
      return;
    }
    counted = true;
    tx.set(viewRef, {
      lastViewedAt: FieldValue.serverTimestamp(),
      lastViewedAtMs: now,
      lastSeenAt: FieldValue.serverTimestamp(),
      lastSeenAtMs: now,
    }, { merge: true });
    tx.update(postRef, { viewCount: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp() });
  });

  return { ok: true, counted };
});

function escapeAttr(value, max = 500) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
    .slice(0, max);
}

function safeJsonForHtml(value) {
  return JSON.stringify(value)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');
}

function safeOgImage(value) {
  const raw = String(value || '').trim();
  try {
    const url = new URL(raw);
    if (url.protocol === 'https:') return escapeAttr(url.toString(), 1000);
  } catch {}
  return 'https://sosoking.co.kr/og-image.png';
}

// HTML 태그 제거 후 plain text 추출 (meta description용)
function stripHtml(html) {
  return String(html || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&[a-z]+;/gi, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

const seoPost = onRequest({ region: REGION }, async (req, res) => {
  const parts = req.path.split('/').filter(Boolean);
  const id = cleanId(parts[parts.length - 1] || req.query.id);
  if (!id) { res.redirect('https://sosoking.co.kr/'); return; }

  try {
    const snap = await db.doc(`feeds/${id}`).get();
    if (!snap.exists) { res.redirect(`https://sosoking.co.kr/#/detail/${id}`); return; }

    const post = snap.data() || {};
    const title      = escapeAttr(post.title || '소소킹 놀이판', 80);
    const rawDesc    = stripHtml(post.body || post.desc || post.subtitle || '소소킹에서 즐겨요');
    const desc       = escapeAttr(rawDesc, 160);
    const image      = safeOgImage(Array.isArray(post.images) ? post.images[0] : post.thumbnailUrl);
    const url        = `https://sosoking.co.kr/p/${id}`;
    const dest       = `https://sosoking.co.kr/#/detail/${id}`;
    const author     = escapeAttr(post.authorName || '소소러', 40);
    const published  = post.createdAt?.toDate?.()?.toISOString() || new Date().toISOString();
    const modified   = post.updatedAt?.toDate?.()?.toISOString() || published;

    // JSON-LD 구조화 데이터 (구글 리치 결과용). </script> 탈출 방지를 위해 JSON 문자열도 HTML-safe 처리합니다.
    const jsonLd = safeJsonForHtml({
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: post.title || '소소킹 놀이판',
      description: rawDesc.slice(0, 200),
      image: [image],
      datePublished: published,
      dateModified: modified,
      author: { '@type': 'Person', name: post.authorName || '소소러' },
      publisher: {
        '@type': 'Organization',
        name: '소소킹',
        url: 'https://sosoking.co.kr',
        logo: { '@type': 'ImageObject', url: 'https://sosoking.co.kr/icon-512.png' },
      },
      mainEntityOfPage: { '@type': 'WebPage', '@id': url },
    });

    res.set('Cache-Control', 'public, max-age=600');
    res.send(`<!DOCTYPE html><html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${title} | 소소킹</title>
  <meta name="description" content="${desc}">
  <meta property="og:title" content="${title} | 소소킹">
  <meta property="og:description" content="${desc}">
  <meta property="og:image" content="${image}">
  <meta property="og:url" content="${url}">
  <meta property="og:type" content="article">
  <meta property="og:locale" content="ko_KR">
  <meta property="og:site_name" content="소소킹">
  <meta property="article:author" content="${author}">
  <meta property="article:published_time" content="${escapeAttr(published)}">
  <meta property="article:modified_time" content="${escapeAttr(modified)}">
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${title} | 소소킹">
  <meta name="twitter:description" content="${desc}">
  <meta name="twitter:image" content="${image}">
  <link rel="canonical" href="${url}">
  <script type="application/ld+json">${jsonLd}</script>
  <meta http-equiv="refresh" content="0;url=${dest}">
  <script>window.location.replace(${JSON.stringify(dest)});</script>
  <style>body{font-family:-apple-system,sans-serif;max-width:680px;margin:24px auto;padding:0 16px;color:#222}h1{font-size:1.4em;margin-bottom:8px}p{color:#555;line-height:1.6}footer{margin-top:16px;font-size:.85em;color:#888}a{color:#FF4422}</style>
</head>
<body>
  <p><a href="https://sosoking.co.kr">← 소소킹</a></p>
  <h1>${title}</h1>
  <p>${desc}</p>
  <footer>${author} · <time datetime="${escapeAttr(published)}">${escapeAttr(published.slice(0, 10))}</time></footer>
  <p style="margin-top:24px"><a href="${dest}">전체 내용 보기 →</a></p>
</body></html>`);
  } catch {
    res.redirect(`https://sosoking.co.kr/#/detail/${id}`);
  }
});

module.exports = {
  castFeedVote,
  toggleFeedReaction,
  registerPostView,
  seoPost,
};