'use strict';

const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { getApps, initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const https = require('https');

if (!getApps().length) initializeApp();
const adminAuth = getAuth();
const db = getFirestore();

const KAKAO_JS_APP_KEY = '377995fee0850a5de4167641d343be0e';
const ALLOWED_REDIRECT_URIS = new Set([
  'https://sosoking.co.kr',
  'https://www.sosoking.co.kr',
]);

function assertAllowedRedirectUri(redirectUri) {
  const normalized = String(redirectUri || '').trim().replace(/\/$/, '');
  if (!ALLOWED_REDIRECT_URIS.has(normalized)) {
    throw new HttpsError('invalid-argument', '허용되지 않은 카카오 로그인 redirectUri입니다.');
  }
  return normalized;
}

function exchangeKakaoCode(code, redirectUri) {
  return new Promise((resolve, reject) => {
    const body = [
      'grant_type=authorization_code',
      `client_id=${encodeURIComponent(KAKAO_JS_APP_KEY)}`,
      `redirect_uri=${encodeURIComponent(redirectUri)}`,
      `code=${encodeURIComponent(code)}`,
    ].join('&');
    const req = https.request({
      hostname: 'kauth.kakao.com',
      path: '/oauth/token',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
      },
    }, res => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          if (json.access_token) resolve(json.access_token);
          else reject(new Error('Kakao token exchange failed: ' + data));
        } catch (e) { reject(e); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function fetchKakaoUser(accessToken) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        hostname: 'kapi.kakao.com',
        path: '/v2/user/me',
        method: 'GET',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8',
        },
      },
      (res) => {
        let body = '';
        res.on('data', (chunk) => { body += chunk; });
        res.on('end', () => {
          try {
            const data = JSON.parse(body);
            if (data.id) resolve(data);
            else reject(new Error('Kakao API error: ' + body));
          } catch (e) {
            reject(e);
          }
        });
      }
    );
    req.on('error', reject);
    req.end();
  });
}

exports.kakaoLogin = onCall({ region: 'asia-northeast3' }, async (request) => {
  let { accessToken, code, redirectUri } = request.data || {};

  if (!accessToken && code) {
    redirectUri = assertAllowedRedirectUri(redirectUri);
    try {
      accessToken = await exchangeKakaoCode(code, redirectUri);
    } catch (e) {
      console.error('[kakaoLogin] code exchange error:', e.message);
      throw new HttpsError('unauthenticated', '카카오 인증 코드 교환 실패: ' + e.message);
    }
  }

  if (!accessToken || typeof accessToken !== 'string' || accessToken.length < 10) {
    throw new HttpsError('invalid-argument', '카카오 액세스 토큰 또는 인증 코드가 필요해요');
  }

  let kakaoUser;
  try {
    kakaoUser = await fetchKakaoUser(accessToken);
  } catch (e) {
    console.error('[kakaoLogin] Kakao API error:', e.message);
    throw new HttpsError('unauthenticated', '카카오 인증에 실패했어요. 다시 시도해주세요.');
  }

  const kakaoId = String(kakaoUser.id);
  const uid = `kakao_${kakaoId}`;

  const kakaoAccount = kakaoUser.kakao_account || {};
  const profile = kakaoAccount.profile || {};
  const displayName = profile.nickname || `카카오${kakaoId.slice(-4)}`;
  const photoURL = profile.profile_image_url || null;
  const email = kakaoAccount.email || null;

  let customToken;
  try {
    customToken = await adminAuth.createCustomToken(uid, {
      provider: 'kakao',
      kakaoId,
    });
  } catch (e) {
    console.error('[kakaoLogin] createCustomToken error:', e.message);
    throw new HttpsError('internal', '로그인 처리에 실패했어요');
  }

  try {
    const userRef = db.doc(`users/${uid}`);
    const existingSnap = await userRef.get().catch(() => null);
    const existingNickname = existingSnap?.data()?.nickname || null;

    // 닉네임이 없는 신규 사용자면 카카오 displayName으로 자동 설정 시도
    let autoNickname = null;
    if (!existingNickname) {
      const candidate = (displayName || '').replace(/[^가-힣a-zA-Z0-9_]/g, '').slice(0, 12);
      if (candidate && candidate.length >= 2) {
        const nickRef = db.doc(`nicknames/${candidate}`);
        const nickSnap = await nickRef.get().catch(() => null);
        if (!nickSnap?.exists) {
          autoNickname = candidate;
        }
      }
    }

    const batch = db.batch();
    batch.set(userRef, {
      displayName,
      photoURL,
      ...(email ? { email } : {}),
      ...(autoNickname ? { nickname: autoNickname } : {}),
      provider: 'kakao',
      kakaoId,
      updatedAt: FieldValue.serverTimestamp(),
    }, { merge: true });

    if (autoNickname) {
      batch.set(db.doc(`nicknames/${autoNickname}`), {
        uid,
        createdAt: FieldValue.serverTimestamp(),
      });
    }

    await batch.commit();
  } catch (e) {
    console.warn('[kakaoLogin] Firestore update error (non-fatal):', e.message);
  }

  return { customToken, displayName, photoURL };
});
