import { db } from '../firebase.js';
import { collection, query, orderBy, limit, getDocs, where } from 'https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js';
import { navigate } from '../router.js';
import { escHtml } from '../utils/helpers.js';

const WEEKLY_WORDS = [
  '소소킹', '킹받네', '라면왕', '웃참패',
  '월요일', '퇴근길', '대반전', '편의점',
  '고양이', '배달비', '알바생', '휴대폰',
  '아메리카노', '지하철역', '치킨게임', '퇴근요정',
  '소확행러', '월급루팡', '반전매력', '웃음버튼',
];

function getPoemType(word) {
  const len = [...String(word || '')].length;
  return ({ 3: '삼행시', 4: '사행시', 5: '오행시', 6: '육행시' })[len] || '삼행시';
}

export async function renderMission() {
  const el = document.getElementById('page-content');
  el.innerHTML = `<div class="loading-center"><div class="spinner spinner--lg"></div></div>`;

  const missions = await fetchMissions();
  const weeklyWord = getWeeklyAcrosticWord();

  el.innerHTML = `
    <div style="max-width:720px;margin:0 auto">
      <div class="section-header">
        <h1 class="section-title">오늘의 미션 🎯</h1>
      </div>
      <p style="font-size:13px;color:var(--color-text-secondary);margin-bottom:18px">
        매일 새로운 미션이 올라와요. 미션에 참여하고 리액션을 받아보세요!
      </p>
      ${renderWeeklyAcrosticChallenge(weeklyWord)}
      ${missions.length
        ? missions.map(m => renderMissionCard(m)).join('')
        : `<div class="empty-state">
            <div class="empty-state__icon">🌙</div>
            <div class="empty-state__title">오늘의 미션이 없어요</div>
            <div class="empty-state__desc">내일 다시 확인해보세요!</div>
          </div>`}
      <div class="card" style="margin-top:24px;padding:20px;text-align:center">
        <div style="font-size:24px;margin-bottom:8px">✍️</div>
        <div style="font-size:15px;font-weight:700;margin-bottom:4px">미션과 관련 없이 글을 올려도 좋아요</div>
        <div style="font-size:13px;color:var(--color-text-secondary);margin-bottom:16px">놀이판은 언제든 만들 수 있어요!</div>
        <button class="btn btn--primary" onclick="navigate('/write')">놀이판 만들기</button>
      </div>
    </div>`;
}

function renderWeeklyAcrosticChallenge(word) {
  const poemType = getPoemType(word);
  return `
    <div class="mission-weekly-card card">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap">
        <div>
          <div class="mission-weekly-card__label">✍️ 이번 주 ${poemType} 챌린지</div>
          <div class="mission-weekly-card__word">${escHtml(word)}</div>
          <div style="font-size:13px;color:var(--color-text-secondary);margin-top:5px">이번 주 제시어로 ${poemType} 왕좌에 도전해보세요.</div>
        </div>
        <button class="btn btn--primary btn--sm" onclick="navigate('/write?type=acrostic&keyword=${escHtml(word)}')">${poemType} 만들기</button>
      </div>
      <div style="display:grid;gap:6px;margin-top:14px">
        ${[...word].map(ch => `<div style="display:flex;align-items:center;gap:8px"><span class="mission-weekly-card__char">${escHtml(ch)}</span><span style="font-size:13px;color:var(--color-text-secondary)">: 센스 있는 한 줄을 채워보세요</span></div>`).join('')}
      </div>
    </div>`;
}

function renderMissionCard(mission) {
  const typeLabels = {
    vote:'골라킹', initial_game:'초성게임', random_battle:'랜덤대결',
    naming:'미친작명소', crazy_court:'억까재판', drip:'한줄드립',
    quiz:'미친퀴즈', relay:'막장킹', acrostic:'삼행시짓기',
  };
  const typeLabel = typeLabels[mission.type] || '자유';
  return `
    <div class="mission-card card">
      <div class="mission-card__header">
        <div class="mission-card__date">오늘의 미션</div>
        <div class="mission-card__title">${escHtml(mission.title || '')}</div>
      </div>
      <div class="mission-card__body">
        ${mission.desc ? `<p style="font-size:13px;color:var(--color-text-secondary);margin-bottom:12px">${escHtml(mission.desc)}</p>` : ''}
        <div style="display:flex;align-items:center;gap:8px">
          <span class="badge badge--primary">${typeLabel}</span>
          <button class="btn btn--primary btn--sm" onclick="navigate('/write?type=${mission.type || ''}')">이 미션 참여하기</button>
        </div>
      </div>
    </div>`;
}

async function fetchMissions() {
  try {
    const q = query(collection(db, 'missions'), where('active', '==', true), orderBy('createdAt', 'desc'), limit(5));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  } catch { return []; }
}

function getWeeklyAcrosticWord() {
  const now = new Date();
  const kst = new Date(now.getTime() + 9 * 60 * 60 * 1000);
  const start = new Date(Date.UTC(kst.getUTCFullYear(), 0, 1));
  const diffDays = Math.floor((kst - start) / 86400000);
  const week = Math.floor(diffDays / 7);
  return WEEKLY_WORDS[week % WEEKLY_WORDS.length];
}
